﻿namespace InterlockedCmpExch
{
	static class Program
	{
		static void Main()
		{
		}
	}
}
